function psai = psaifunc(m,n)
psai0 = cell(length(m), 4);
psai = cell(1, length(m)+3);
for i= 1:1:length(m)
    for j=1:1:4
        psai0{i,j} = m(i) * n{j};
    end
end
for k = 1:1:length(m)+3
    psai{k} = zeros(1,100);
    for i =1:1:length(m)
        for j=1:1:4
            if i+j == k+1
                psai{k} = psai{k}+psai0{i,j};
            end
        end
    end
end
psai = cell2mat(psai)*2;