% The 2D basis for rangeval
function Cov_cons = cov_hiconv(rangeval, coeffi_blc, b1_name,basis1, b2_name,basis2, n11, n12, n21, n22,m)

basis1 = [basis1,0];
basis2 = [basis2,0];

% If basis1==Cphi, then the number of k1 is different
if strcmp(b1_name, 'Cphi') ==1
    m11 = -2.^m-n11+4; m12=2.^(m+1)-n12-3;
else
    m11 = -2.^m-n11+1; m12=2.^(m+1);
end
tau1 = (n11-n12)/(length(basis1)-1);

% If basis2==Cphi, then the number of k1 is different
if strcmp(b2_name, 'Cphi') ==1
    m21 = -2.^m-n21+4; m22=2.^(m+1)-n22-3;

else
    m21 = -2.^m-n21+1; m22=2.^(m+1);
end
tau2 = (n21-n22)/(length(basis2)-1);


basisH1 =[];
for k1 = m11:1:m12
    
    tcopy1 = 2.^m * rangeval - k1;
    tcopy1(tcopy1>n11)=0;
    tcopy1(tcopy1<n12)=0;
    tp1 = floor(tcopy1/tau1);
    if strcmp(b1_name, 'Cphi') ==1
        basisHat1 = basis1(tp1+601);
    else
        basisHat1 = basis1(tp1+1);
    end
    basisHat1 =basisHat1';
    basisH1 = [basisH1, basisHat1];
end

basisH2 =[];
for k2 = m21:1:m22
    tcopy2 = 2.^m * rangeval -k2;
    tcopy2(tcopy2>n21)=0;
    tcopy2(tcopy2<n22)=0;
    tp2 = floor(tcopy2/tau2);
    if strcmp(b2_name, 'Cphi') ==1
        basisHat2 = basis2(tp2+601);
    else
        basisHat2 = basis2(tp2+1);
    end
    basisH2 = [basisH2;basisHat2];
end

Cov_cons = basisH1 * coeffi_blc;
Cov_cons =2.^m * Cov_cons * basisH2;
