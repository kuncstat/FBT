% Convolution path
function path = cov_path(rangeval, coeffi_blc, b1_name,basis1, b2_name,basis2, n11, n12, n21, n22, scale_level)

path =zeros(length(rangeval), length(rangeval));
for k=1:1:length(coeffi_blc)
    dsb = cov_hiconv(rangeval, coeffi_blc{k,1}, b1_name,basis1, b2_name,basis2, n11,n12,n21,n22, k-1+scale_level);
    path = path+dsb;
end
