% 2D framelets
function coeffi = Cov_basis(t,Cov_raw, b1_name,basis1, b2_name,basis2, m, n11,n12, n21,n22, ncohort)

basis1 = [basis1,0];
basis2 = [basis2,0];

omega = 9/ncohort;

% If basis1==Cphi, then the number of k1 is different
if strcmp(b1_name, 'Cphi') ==1
    m11 = -2.^m-n11+4; m12=2.^(m+1)-n12-3;
else
    m11 = -2.^m-n11+1; m12=2.^(m+1);
end
tau1 = (n11-n12)/(length(basis1)-1);

% If basis2==Cphi, then the number of k1 is different
if strcmp(b2_name, 'Cphi') ==1
    m21 = -2.^m-n21+4; m22=2.^(m+1)-n22-3;
else
    m21 = -2.^m-n21+1; m22=2.^(m+1);
end
tau2 = (n21-n22)/(length(basis2)-1);




basisH1 =[];
for k1 = m11:1:m12
    tcopy1 = 2.^m * t - k1;
    
    if strcmp(b1_name, 'Cphi') ==1
        tcopy1(tcopy1>n11)=n11;
        tcopy1(tcopy1<n12)=n12;
        tp1 = floor(tcopy1/tau1);
        basisHat1 = basis1(tp1+601);
    else
        tcopy1(tcopy1>n11)=0;
        tcopy1(tcopy1<n12)=0;
        tp1 = floor(tcopy1/tau1);
        basisHat1 = basis1(tp1+1);
    end
    basisH1 = [basisH1;basisHat1];
end

basisH2 =[];
for k2 = m21:1:m22
    tcopy2 = 2.^m * t -k2;
    tcopy2(tcopy2>n21)=0;
    tcopy2(tcopy2<n22)=0;
    tp2 = floor(tcopy2/tau2);
    if strcmp(b2_name, 'Cphi') ==1
        tcopy2(tcopy2>n21)=n21;
        tcopy2(tcopy2<n22)=n22;
        tp2 = floor(tcopy2/tau2);
        basisHat2 = basis2(tp2+601);
    else
        tcopy2(tcopy2>n21)=0;
        tcopy2(tcopy2<n22)=0;
        tp2 = floor(tcopy2/tau2);
        basisHat2 = basis2(tp2+1);
    end
    
    basisHat2 =basisHat2';
    basisH2 = [basisH2,basisHat2];
end

basisHat = basisH1 * Cov_raw;
coeffi = basisHat * basisH2;   

coeffi = coeffi * 2.^m * omega;
        
