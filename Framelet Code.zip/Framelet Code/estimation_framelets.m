function  mu_hat1 = estimation_framelets(t,y,scale_level, level_num, ncohort,Cphi, phi, psai1, psai2, psai3, rangeval, Thr, PVal, cVal)
%%%%
% t: time points, 1*ncohort cell
% y: observations, 1*ncohort cell
% scale_level: the primary resolution level, a number such that
%             2^scale_level is smaller than the interval length of target
% level_num: the maximal resolution level, which is set to be log ncohort
% Cphi and psi_l, 1=<l<=L: the tight framelets. See Daubechies et al.(2003)
% rangeval: the interval of target
% Thr: the block size
% PVal: the truncation
% cVal: the threshold
%%%%%
% outputs: the estimator
alpha = getValue_low(t, y,ncohort, scale_level, 4,0,phi,PVal);

[beta1, beta11] = Coeffi_beta(t,y, ncohort,scale_level, level_num, psai1, 5, Thr, PVal, cVal);
[beta2, beta21] = Coeffi_beta(t,y, ncohort,scale_level, level_num, psai2, 6, Thr, PVal, cVal);
[beta3, beta31] = Coeffi_beta(t,y, ncohort,scale_level, level_num, psai3, 7, Thr, PVal, cVal);

hipath1 = hipath(rangeval, scale_level, level_num, 5, psai1);
hipath2 = hipath(rangeval, scale_level, level_num, 6, psai2);
hipath3 = hipath(rangeval, scale_level, level_num, 7, psai3);

estimator_h1 = estimateHigh(beta1, hipath1,scale_level,level_num);
estimator_h2 = estimateHigh(beta2, hipath2,scale_level,level_num);
estimator_h3 = estimateHigh(beta3, hipath3,scale_level,level_num);
estimator_h  = estimator_h1+estimator_h2+estimator_h3;

estimator_h11 = estimateHigh(beta11, hipath1,scale_level,level_num);
estimator_h21 = estimateHigh(beta21, hipath2,scale_level,level_num);
estimator_h31 = estimateHigh(beta31, hipath3,scale_level,level_num);
estimator_h1  = estimator_h11+estimator_h21+estimator_h31;

lopath = hiconv01(rangeval, scale_level,7,-3, Cphi);
estimator_l = estimateLow(alpha,lopath,scale_level);

mu_hat = estimator_l + estimator_h; 
mu_hat =mu_hat([100:200]);
mu_hat1 = estimator_l + estimator_h1; 
mu_hat1 =mu_hat1([100:200]);

