%% estimation by wavelet thresholding %%

%Part I: generate data set
mtp = 10;

ncohort = 200;
lint = 1;
y = cell(1, ncohort);
t = cell(1, ncohort);

for i = 1:ncohort
    ntp = ceil(mtp * rand(1))+1;
    t{i}=lint*rand(1,ntp);
    
    xi(i,:)=[(1/4)*randn(1) (1/9)*randn(1) (1/16)*randn(1) (1/25)*randn(1)];
%     y{i}=mu_true(t{i},lint)+xi(i,:)*xeig4(t{i},lint);
%    y{i}=mu_true(t{i},lint);
    
    y{i}=mu_true(t{i},lint)+xi(i,:)*xeig4(t{i},lint)+randn(1,length(t{i}));  
    

end

%%
phi = ones(1,1000);
psai1 = ones(1,500); psai2 =-ones(1,500);
psai = [psai1, psai2];

figure
subplot(1,2,1)
u=0.001:0.001:1;
plot(u, phi);
axis([0,1,-0.2,1.2]);
title('\phi(t) Vs t')
hold on

subplot(1,2,2)
u=0.001:0.001:1;
plot(u, psai);
axis([0,1,-1.2,1.2]);
title('\psi(t) Vs t')

%%
phi = [0,phi,1];
psai = [0,psai,-1];
alpha = getValue(t,y,4,1,phi);
rangeval = 0.005:0.005:1;
lopath = hiconv01(rangeval, 4,1,phi);

beta = cell(7,1);
for m =0:1:6
    beta{m+1}=getValue(t,y,m+4,1,psai);
end


hipath = cell(7,1);
for m= 0:1:6
    hipath{m+1} = hiconv(rangeval,m+4,1,psai);
end

estimator_h = estimateHigh(beta, hipath);
estimator_l = estimateLow(alpha,lopath);
mu_hat = estimator_l + estimator_h;


mu_sb = 1.5 * sin(3*pi*(rangeval+0.5))+2*rangeval.^3;
ysb = cell2mat(y);
tsb = cell2mat(t);
% mu_sb = mu_sb(10:90);
figure
plot(rangeval,mu_hat)
hold on
plot(rangeval,mu_sb)
