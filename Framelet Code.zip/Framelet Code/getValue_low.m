function alpha = getValue_low(t, y ,ncohort, m, n1,n2, basis,PVal)
basis = [basis,0];

omega = 3/ncohort;
m1 = -2.^m-n1+1; m2=2.^(m+1);
y = repmat(y,m2-m1+1,1);
tau = (n1-n2)/(length(basis)-1);

tp = zeros(m2-m1+1, length(t));
phiHat = zeros(m2-m1+1, length(t));

for k = m1:1:m2
    tcopy = 2.^m * t -k;
    tcopy(tcopy>n1)=0;
    tcopy(tcopy<n2)=0;
    tp(k-m1+1,:) = floor(tcopy/tau);
end
phiHat = basis(tp+1);
phiHat = y.*phiHat ;
% for i=1:1:m2-m1+1
%     phiVal = phiHat(i,:);
%     phiVal(find(phiVal>PVal))=PVal;
%     phiVal(find(phiVal<-PVal)) = -PVal;
%     phiHat(i,:)=phiVal;
% end
alpha = sum(phiHat,2);
alpha = alpha * omega * 2.^(m/2);


