% Covariance estimation by 2D framelets

%% Part I: Given the 1D framelets 
t0 = 317784/7775 + 56*sqrt(16323699891)/2418025;
t1 = sqrt(11113747578360- 245493856965*t0)/62697600;
t2 = sqrt(1543080- 32655*t0)/40320;
t3 = sqrt(32655)/20160;
t01 = 7775*t0/4396 - 53854/1099;
t02 = t0/8 + 21;
b1 = [1, 4, -25, 40, -25, 4, 1] * t1;
b2 = [1, 4, t01-26, 52-4*t01, 6*t01-62, 52-4*t01, t01-26, 4, 1] * t2;
b3 = [1, 4, t02-26, t0-4*t02+44, 7*t02-4*t0-31, 6*t0+16-8*t02, 7*t02-4*t0-31, t0-4*t02+44, t02-26, 4, 1]*t3;

% the code is for scale function \phi(t) defined on [0,4]
bs0 = splinefunc(0);
phi = generate_phi(bs0);
% give the formula of C_{theta}phi ,which is defined on [-3,7]
Cphi = generate_Ctheta_phi(phi);

% the code is for wavelet functions {\psai(t)} 
% defined on [0,5] [0,6] and [0,7], respectively.
psai1 = psaifunc(b1,bs0);
psai2 = psaifunc(b2,bs0);
psai3 = psaifunc(b3,bs0);



%% Iteration 
ncohort =200;
% rangeval = -0.99:0.01:2;
rangeval = -0.99:0.01:2;

%% True Covariance
lint=1;
rangeval1 = 0:0.01:1;
truecov =[];
%%

for i=1:length(rangeval1)
    for j=1:length(rangeval1)
        truecov(i,j)=xeig4(rangeval1(i),lint)'*diag([1/4,1/9,1/16,1/25])*xeig4(rangeval1(j),lint);
    end
end
    
    
    
Thr=18;
cVal =.85;
scale_level=2;
level_num = floor(log2(ncohort)/2);
% level_num =1;
SetOption =1;

[tcov,Cov_raw] = raw_cov(SetOption, ncohort, 1, 0.5);
[cov_func, coeffi_scale, lopath1cov, covfunc1]  = cov_reconstruct(tcov,Cov_raw, rangeval, scale_level, level_num, ncohort, 'Cphi',Cphi, 'phi',phi, 'psai1',psai1, 'psai2',psai2, 'psai3',psai3, Thr, cVal);

Mise = sum(sum((truecov - covfunc1).^2))/10000;
Mise

Msae = max(max(abs(truecov - covfunc1)));
Msae
mesh(covfunc1)
% figure
% mesh(truecov)
