% 2D Blockthresholding
function coeffi_Block = Cov_BThres(coeffi, ncohort, l, cval)

[m,n]= size(coeffi);
coeffi_Block = zeros(m,n);
omega = 1/ncohort;


lenl1 = 1:1:m;
lenl2 = 1:1:n;

block_num1 = ceil(m/l);
block_num2 = ceil(n/l);

for p=1:1:block_num1
    lowbound1 = (p-1)*l+1; upperbound1=p*l;
    Inx1 = intersect(lenl1(lenl1 >=lowbound1),lenl1(lenl1 <=upperbound1));
    for q=1:1:block_num2
        lowbound2 = (q-1)*l+1; upperbound2=q*l;
        Inx2 = intersect(lenl2(lenl2 >=lowbound2),lenl2(lenl2 <=upperbound2));
        Value_block = coeffi(Inx1, Inx2);
        Value_block = sum(sum(Value_block.^2))/numel(Value_block);
        if Value_block < cval*omega
            coeffi_Block(Inx1,Inx2) = 0;
        else
            coeffi_Block(Inx1, Inx2) = coeffi(Inx1, Inx2);
        end
    end
end
        
        
        