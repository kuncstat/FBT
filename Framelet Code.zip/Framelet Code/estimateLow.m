function estimator_l = estimateLow(coeffi,basis, level)
    m1 = length(coeffi);
    estimator_l = zeros(300,1);
    for k = 1:1:m1
        estimator_l = estimator_l + coeffi(k)*basis(k,:)';
    end
    estimator_l = estimator_l * 2.^(level/2) ;
    