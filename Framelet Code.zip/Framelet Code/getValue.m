function alpha = getValue(t, y ,ncohort, m, n, basis, PVal)
basis = [basis,0];

omega = 3/ncohort;
m1 = -2.^m-n+1; m2=2.^(m+1);
y = repmat(y,m2-m1+1,1);
tau = n/(length(basis)-1);

tp = zeros(m2-m1+1, length(t));
phiHat = zeros(m2-m1+1, length(t));

for k = m1:1:m2
    tcopy = 2.^m * t -k;
    tcopy(tcopy>n)=0;
    tcopy(tcopy<0)=0;
    tp(k-m1+1,:) = floor(tcopy/tau);
end
phiHat = basis(tp+1);
phiHat = y.*phiHat ;
% for i=1:1:m2-m1+1
%     phiVal = phiHat(i,:);
%     phiVal(find(phiVal>PVal))=PVal;
%     phiVal(find(phiVal<-PVal)) = -PVal;
%     phiHat(i,:)=phiVal;
% end
alpha = sum(phiHat,2);
alpha = alpha * omega * 2.^(m/2);





        
        