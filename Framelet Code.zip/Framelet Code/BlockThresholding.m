function coeffi_Block = BlockThresholding(t, coeffi, ncohort, l, c)

[m,n]= size(coeffi);
coeffi_Block = cell(m,n);
omega = 1/ncohort;

for k=1:1:m
    lenkl = 1:1:length(coeffi{k,1});
    block_number = ceil(length(lenkl)/l);
    for p=1:1:block_number
%         dsb=0;
        lowbound=(p-1)*l+1; upperbound=p*l;
        block_index1 = lenkl(lenkl >=lowbound);
        block_index2 = lenkl(lenkl <=upperbound);
        block_index = intersect(block_index1, block_index2);
%         for j=1:1:length(coeffi{k,1})
%             if j>=lowbound && j<=upperbound
%                 dsb = dsb + coeffi{k,1}(j).^2;
%             end
%         end

        block_value = coeffi{k,1}(block_index);
        block_length = length(block_value);
        dsb = sum(block_value.^2);
        if dsb/block_length < c*omega
            coeffi_Block{k,1}(block_index) =0;
        else
            coeffi_Block{k,1}(block_index) = coeffi{k,1}(block_index);
        end
    end
end 
        
        
    