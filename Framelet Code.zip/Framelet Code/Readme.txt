1. mean estimation
estimation_framelets: the main function of FBT
lwls: the LLSs with obs and subj weighing schemes
RKHS&Spline.R: the implementation of smoothing spline estimate

2. covariance estimation
cov_reconstruct: the main function of FBT
mullwlsk: the obs and subj LLSs 
RKHS&Spline.R: the implementation of RKHS approach

RunCode & Runcov: the code for simulations
demo: the code for real data
