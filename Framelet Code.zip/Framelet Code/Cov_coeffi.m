% Obatin coefficients in different levels

function [coeffi, coeffi_blc] = Cov_coeffi(t1,Cov_raw, b1_name,basis1, b2_name,basis2, n11, n12, n21, n22, scale_level, level_num, ncohort, l, cval)

coeffi = cell(level_num, 1);
coeffi_blc = cell(level_num,1);
%%% Get coefficients 
for m = 0:1: level_num-1
coeffi{m+1} = Cov_basis(t1, Cov_raw, b1_name,basis1, b2_name,basis2, m+scale_level, n11, n12, n21, n22, ncohort);
coeffi_blc{m+1} = Cov_BThres(coeffi{m+1}, ncohort, l, cval);
end