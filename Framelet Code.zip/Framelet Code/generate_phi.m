function phi = generate_phi(bs0)
b0 = [1, 4, 6, 4, 1]/16;
phi0 = cell(length(b0), 4);
phi = cell(1, 8);
for i=1:1:length(b0)
    for j=1:1:4
        phi0{i,j} = b0(i) * bs0{j};
    end
end
for k = 1:1:8
    phi{k} = zeros(1,100);
    for i=1:1:length(b0)
        for j = 1:1:4
            if i+j == k+1
                phi{k} = phi{k}+phi0{i,j};
            end
        end
    end
end
phi = cell2mat(phi)*2;