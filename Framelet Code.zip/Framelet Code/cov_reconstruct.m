% Reconstruction of covariance function
function [covfunc1] = cov_reconstruct(t1,Cov_raw, rangeval, scale_level, level_num, ncohort,nm1,Cphi, nm2, phi, nm3,psai1, nm4,psai2, nm5,psai3,Thr, cVal)

%% Scale coefficients
[coeffi_scale, coeffi_blc_scale] = Cov_coeffi(t1,Cov_raw, nm2,phi, nm2,phi, 4,0,4,0, scale_level, 1, ncohort, Thr, cVal);

%% Framelets coefficients
%%% basis1 = Cphi
[coeffi_frame11, coeffi_blc_frame11] = Cov_coeffi(t1,Cov_raw, nm2,phi, nm3,psai1, 4,0,5,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame12, coeffi_blc_frame12] = Cov_coeffi(t1,Cov_raw, nm2,phi, nm4,psai2, 4,0,6,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame13, coeffi_blc_frame13] = Cov_coeffi(t1,Cov_raw, nm2,phi, nm5,psai3, 4,0,7,0, scale_level, level_num, ncohort, Thr, cVal);
%%% basis1 = psai1
[coeffi_frame21, coeffi_blc_frame21] = Cov_coeffi(t1,Cov_raw, nm3,psai1, nm2,phi, 5,0,4,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame22, coeffi_blc_frame22] = Cov_coeffi(t1,Cov_raw, nm3,psai1, nm3,psai1, 5,0,5,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame23, coeffi_blc_frame23] = Cov_coeffi(t1,Cov_raw, nm3,psai1, nm4,psai2, 5,0,6,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame24, coeffi_blc_frame24] = Cov_coeffi(t1,Cov_raw, nm3,psai1, nm5,psai3, 5,0,7,0, scale_level, level_num, ncohort, Thr, cVal);
%%% basis1 = psai2
[coeffi_frame31, coeffi_blc_frame31] = Cov_coeffi(t1,Cov_raw, nm4,psai2, nm2,phi, 6,0,4,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame32, coeffi_blc_frame32] = Cov_coeffi(t1,Cov_raw, nm4,psai2, nm3,psai1, 6,0,5,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame33, coeffi_blc_frame33] = Cov_coeffi(t1,Cov_raw, nm4,psai2, nm4,psai2, 6,0,6,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame34, coeffi_blc_frame34] = Cov_coeffi(t1,Cov_raw, nm4,psai2, nm5,psai3, 6,0,7,0, scale_level, level_num, ncohort, Thr, cVal);
%%% basis1 = psai3
[coeffi_frame41, coeffi_blc_frame41] = Cov_coeffi(t1,Cov_raw, nm5,psai3, nm2,phi, 7,0,4,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame42, coeffi_blc_frame42] = Cov_coeffi(t1,Cov_raw, nm5,psai3, nm3,psai1, 7,0,5,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame43, coeffi_blc_frame43] = Cov_coeffi(t1,Cov_raw, nm5,psai3, nm4,psai2, 7,0,6,0, scale_level, level_num, ncohort, Thr, cVal);
[coeffi_frame44, coeffi_blc_frame44] = Cov_coeffi(t1,Cov_raw, nm5,psai3, nm5,psai3, 7,0,7,0, scale_level, level_num, ncohort, Thr, cVal);

%% High path
%%% basis1 = Cphi
hipath11 = cov_path(rangeval,coeffi_blc_frame11, nm1,Cphi, nm3,psai1, 7,-3,5,0, scale_level);
hipath12 = cov_path(rangeval,coeffi_blc_frame12, nm1,Cphi, nm4,psai2, 7,-3,6,0, scale_level);
hipath13 = cov_path(rangeval,coeffi_blc_frame13, nm1,Cphi, nm5,psai3, 7,-3,7,0, scale_level);
hipath1 = hipath11 + hipath12 + hipath13;
%%% basis1 = psai1
hipath21 = cov_path(rangeval,coeffi_blc_frame21, nm3,psai1, nm1,Cphi, 5,0,7,-3, scale_level);
hipath22 = cov_path(rangeval,coeffi_blc_frame22, nm3,psai1, nm3,psai1, 5,0,5,0, scale_level);
hipath23 = cov_path(rangeval,coeffi_blc_frame23, nm3,psai1, nm4,psai2, 5,0,6,0, scale_level);
hipath24 = cov_path(rangeval,coeffi_blc_frame24, nm3,psai1, nm5,psai3, 5,0,7,0, scale_level);
hipath2 = hipath21 + hipath22 + hipath23 + hipath24;
%%% basis1 = psai2
hipath31 = cov_path(rangeval,coeffi_blc_frame31, nm4,psai2, nm1,Cphi, 6,0,7,-3, scale_level);
hipath32 = cov_path(rangeval,coeffi_blc_frame32, nm4,psai2, nm3,psai1, 6,0,5,0, scale_level);
hipath33 = cov_path(rangeval,coeffi_blc_frame33, nm4,psai2, nm4,psai2, 6,0,6,0, scale_level);
hipath34 = cov_path(rangeval,coeffi_blc_frame34, nm4,psai2, nm5,psai3, 6,0,7,0, scale_level);
hipath3 = hipath31 + hipath32 + hipath33 + hipath34;
%%% basis1 = psai3
hipath41 = cov_path(rangeval,coeffi_blc_frame41, nm5,psai3, nm1,Cphi, 7,0,7,-3, scale_level);
hipath42 = cov_path(rangeval,coeffi_blc_frame42, nm5,psai3, nm3,psai1, 7,0,5,0, scale_level);
hipath43 = cov_path(rangeval,coeffi_blc_frame43, nm5,psai3, nm4,psai2, 7,0,6,0, scale_level);
hipath44 = cov_path(rangeval,coeffi_blc_frame44, nm5,psai3, nm5,psai3, 7,0,7,0, scale_level);
hipath4 = hipath41 + hipath42 + hipath43 + hipath44;

%% Low path
lopath1cov = cov_path(rangeval, coeffi_scale, nm1,Cphi, nm1,Cphi, 7,-3,7,-3, scale_level);

%% Estimation value
cov_func = hipath1 +hipath2 +hipath3 +hipath4 +lopath1cov;
covfunc1 = cov_func(100:200, 100:200);



