function Cphi = generate_Ctheta_phi(phi)

theta = [-311/15120, 22/105, -1657/1680, 2452/945, -1657/1680, 22/105, -311/15120];

Ctheta_phi = cell(1,4);
Ctheta_phi{1} = phi([1:1:200]);
Ctheta_phi{2} = phi([201:1:400]);
Ctheta_phi{3} = phi([401:1:600]);
Ctheta_phi{4} = phi([601:1:800]);
Cphi0 =cell(1,4);
Cphi = cell(1, 10);
for i=1:1:length(theta)
    for j=1:1:4
        Cphi0{i,j} = theta(i) * Ctheta_phi{j};
    end
end
for k = 1:1:10
    Cphi{k} = zeros(1,200);
    for i=1:1:length(theta)
        for j = 1:1:4
            if i+j == k+1
                Cphi{k} = Cphi{k}+Cphi0{i,j};
            end
        end
    end
end
Cphi = cell2mat(Cphi);