function hipath = hiconv01(rangeval,m,n1,n2,basis)

basis = [basis,0];
m1 =-2.^m-n1+4; m2=2.^(m+1)-n2-3;
lens =length(rangeval);
tm = zeros(m2-m1+1,lens);

hipath = zeros(size(tm));

tau = (n1-n2)/(length(basis)-1);

for k = m1:1:m2
    tcopy = 2.^m * rangeval -k;
    tcopy(tcopy>n1)=7;
    tcopy(tcopy<n2)=-3;
    tm(k-m1+1,:) = floor(tcopy/tau);
end
    hipath = basis(tm +601);

