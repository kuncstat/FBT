function [t1,y1,win2,t,y] = generate_data(SetOption, ncohort,w1,w2, sigma)
lint = 1;
y = cell(1, ncohort);
t = cell(1, ncohort);
t1 = cell(size(t));
y1 = cell(size(y));
win2 = cell(size(y));
%Setting I: N_i are i.i.d. from a discrete uniform distribution on the set {2, 3, 4, 5}.
%Setting II: N_i = n/4 with probability 0.5, and follow Setting 1 with probability 0.5.
%Setting III: N_i = n/4 with probability n^?1/2, and follow Setting 1 with probability1?n^?1/2.
%Setting IV: N_i are i.i.d. from a discrete uniform distribution on the interval[n/8, 3n/8].

if SetOption==1
    mtp =4;
    for i = 1:ncohort
        ntp = ceil(mtp * rand(1))+1;
        t{i}=lint*rand(1,ntp);
    
        xi(i,:)=[(1/2)*randn(1) (1/3)*randn(1) (1/4)*randn(1) (1/5)*randn(1)];
%     y{i}=mu_true(t{i},lint)+xi(i,:)*xeig4(t{i},lint);
%    y{i}=mu_true(t{i},lint);
    
        y{i}=mu_true(w1,w2,t{i},lint)+xi(i,:)*xeig4(t{i},lint)+sigma*randn(1,length(t{i}));  
    

    end
    
elseif SetOption==2
    mtp1 =4;
    mtp2 =ncohort/4;
    for i=1:ncohort/2
        ntp1 = ceil(mtp1 * rand(1))+1;
        t{i} = lint*rand(1,ntp1);
        ntp2 = ceil(mtp2)+1;
        t{i+ncohort/2} = lint*rand(1,ntp2);
        
        xi(i,:)=[(1/2)*randn(1) (1/3)*randn(1) (1/4)*randn(1) (1/5)*randn(1)];
        xi(i+ncohort/2,:)=[(1/2)*randn(1) (1/3)*randn(1) (1/4)*randn(1) (1/5)*randn(1)];
        
        y{i}=mu_true(w1,w2,t{i},lint)+xi(i,:)*xeig4(t{i},lint)+sigma*randn(1,length(t{i}));
        y{i++ncohort/2}=mu_true(w1,w2,t{i+ncohort/2},lint)+xi(i+ncohort/2,:)*xeig4(t{i+ncohort/2},lint)+sigma*randn(1,length(t{i+ncohort/2}));
    end
    
elseif SetOption==3
    mtp2 =4;
    mtp1 =ncohort/8;
    sampleNum = ncohort^(0.5)*4;
    sampleNum =ceil(ncohort/sampleNum);
    for i=1:sampleNum
        ntp1 = ceil(mtp1)+1;
        t{i} = lint*rand(1,ntp1);
        
        xi(i,:)=[(1/2)*randn(1) (1/3)*randn(1) (1/4)*randn(1) (1/5)*randn(1)];
        
        y{i}=mu_true(w1,w2,t{i},lint)+xi(i,:)*xeig4(t{i},lint)+sigma*randn(1,length(t{i}));
    end
    for i=sampleNum+1:ncohort
        ntp2 = ceil(mtp2 * rand(1))+1;
        t{i} = lint*rand(1,ntp2);
        
        xi(i,:)=[(1/2)*randn(1) (1/3)*randn(1) (1/4)*randn(1) (1/5)*randn(1)];
        
        y{i}=mu_true(w1,w2,t{i},lint)+xi(i,:)*xeig4(t{i},lint)+sigma*randn(1,length(t{i}));
    end
elseif SetOption==4
    mtp1 = floor(ncohort/8);
    mtp2 = floor(3*ncohort/8);
    for i = 1:ncohort
        ntp = ceil(mtp1+(mtp2-mtp1) * rand(1))+1;
        t{i}=lint*rand(1,ntp);
    
        xi(i,:)=[(1/2)*randn(1) (1/3)*randn(1) (1/4)*randn(1) (1/5)*randn(1)];    
        y{i}=mu_true(w1,w2,t{i},lint)+xi(i,:)*xeig4(t{i},lint)+sigma*randn(1,length(t{i}));  
    end
       
elseif SetOption ==5
    load('/Users/chengkun/Desktop/Framelet Code/cd4_num.mat');
    load('/Users/chengkun/Desktop/Framelet Code/time.mat');
    for i=1:1:ncohort
        t{i}= time{i}'./5.9;
        y{i}= cd4_num{i}'./60;
    end
end
    
  
% t_symR = cell(1, ncohort); t_symL = cell(1,ncohort);
for i=1:1:ncohort
    t_symR{i} = 2-t{i};
    t_symL{i} = -t{i};
    t1{i} = [t_symL{1,i}, t{i}, t_symR{1,i}];
    y1{i} = [y{i}, y{i}, y{i}];
    Ni = length(y1{i});
    y1{i} = y1{i}/Ni;

    Mi = length(y{i});
    win2{i} = ones(1,Mi)/Mi;
    win2{i} = win2{i}/ncohort;

end