% Covariance estimation by 2D framelets

%% Part I: Given the 1D framelets 
t0 = 317784/7775 + 56*sqrt(16323699891)/2418025;
t1 = sqrt(11113747578360- 245493856965*t0)/62697600;
t2 = sqrt(1543080- 32655*t0)/40320;
t3 = sqrt(32655)/20160;
t01 = 7775*t0/4396 - 53854/1099;
t02 = t0/8 + 21;
b1 = [1, 4, -25, 40, -25, 4, 1] * t1;
b2 = [1, 4, t01-26, 52-4*t01, 6*t01-62, 52-4*t01, t01-26, 4, 1] * t2;
b3 = [1, 4, t02-26, t0-4*t02+44, 7*t02-4*t0-31, 6*t0+16-8*t02, 7*t02-4*t0-31, t0-4*t02+44, t02-26, 4, 1]*t3;

% the code is for scale function \phi(t) defined on [0,4]
bs0 = splinefunc(0);
phi = generate_phi(bs0);
% give the formula of C_{theta}phi ,which is defined on [-3,7]
Cphi = generate_Ctheta_phi(phi);

% the code is for wavelet functions {\psai(t)} 
% defined on [0,5] [0,6] and [0,7], respectively.
psai1 = psaifunc(b1,bs0);
psai2 = psaifunc(b2,bs0);
psai3 = psaifunc(b3,bs0);



%% Iteration 
ncohort =200;
rangeval = -0.99:0.01:2;

%% True Covariance
lint=1;
rangeval1 = 0:0.01:1;
truecov =[];
%%

for i=1:length(rangeval1)
    for j=1:length(rangeval1)
        truecov(i,j)=xeig4(rangeval1(i),lint)'*diag([1/4,1/9,1/16,1/25])*xeig4(rangeval1(j),lint);
    end
end
    
    
    
Thr=18;
para = [0.5:0.1:1.1]*0.2724;
scale_level=2;
% level_num = floor(log2(ncohort)/2);
level_num =1;

SetOption =3;
regular =0;
iter_num=50;

Miblc = zeros(iter_num,length(para)); Mablc= zeros(iter_num,length(para));
Miobs = zeros(iter_num,length(para)); Maobs= zeros(iter_num,length(para));
Misubj = zeros(iter_num,length(para)); Masubj= zeros(iter_num,length(para));
Miss = zeros(iter_num,length(para)); Mass= zeros(iter_num,length(para));

Blc = cell(iter_num,length(para)); 
obs = cell(iter_num,length(para));subj = cell(iter_num,length(para));
ss = cell(iter_num,length(para));

w1 =1; w2=0.5;
sigma =0.1;

% SS
norder = 4;  % the order of splines
pord = 2; % the degree of penalized matrix P

for i = 1:1:iter_num
    [tcov,Cov_raw,to,yo] = raw_cov(SetOption, ncohort,w1,w2,sigma);
    cVal = (2+3*sqrt(49))^2*0.49^4*std(cell2mat(yo)).^4/0.08;
%     cVal=0.2;
    
    [res1] = getRawCov(yo,to,rangeval1, mu_true(w1,w2,rangeval1,lint), regular, 1, 'obs');
    [res2] = getRawCov(yo,to,rangeval1, mu_true(w1,w2,rangeval1,lint), regular, 1, 'subj');
    tin = res1.tpairn; yin = res1.cxxn; 
    win1 = res1.win;   win2 = res2.win;
    
    [cov_func]  = cov_reconstruct(tcov,Cov_raw, rangeval, scale_level, level_num, ncohort,...
            'Cphi',Cphi, 'phi',phi, 'psai1',psai1, 'psai2',psai2, 'psai3',psai3, Thr, cVal);
        
    %SS
    PN=[];
    for kk=1:ncohort
       PN = [PN, length(to{kk})];
    end
    nbasis = floor((ncohort^2 /sum(1./PN))^(1/(2*2+1)))+10;
    BSB = create_bspline_basis([0,1], nbasis, norder);
    BSB = fdPar(BSB); bsbasis = getfd(BSB); bsbasis = getbasis(bsbasis);
    bsb_pv = eval_basis(cell2mat(to), bsbasis);
    ss_D = diff(eye(nbasis), pord);
    ss_bp = eval_basis(rangeval1, bsbasis);
    Sigma_SUBJ = cell(1, ncohort);
    Bb_cov = zeros(nbasis, nbasis); % the bi-splines values at T_ijl
    for k=1:ncohort
        sigmai_SUBJ = mu_true(w1,w2,to{k},lint);
        rci_SUBJ = (yo{k}-sigmai_SUBJ)' * (yo{k}-sigmai_SUBJ);
        rci_SUBJ = rci_SUBJ - diag(diag(rci_SUBJ));
        Sigma_SUBJ{k} = rci_SUBJ(:);
        
        bsb_pv_cov = eval_basis(to{k}, bsbasis);
        Bb_cov = Bb_cov + bsb_pv_cov' * bsb_pv_cov;
    end
    Gbn_cov = Bb_cov/length(cell2mat(to));
    %estimation via ss
    lambda_sigma = 0.1;  % the smoohthing parameters
    Pb_cov = ss_D' * ss_D; % the penality \bar{P}
    P_sigma = lambda_sigma * (kron(Gbn_cov, Pb_cov) + kron(Pb_cov, Gbn_cov))+...
        lambda_sigma^2 * (kron(Pb_cov, Pb_cov)); % the penality matrix 
    Gn_SUBJ = zeros(nbasis^2, nbasis^2); Sigma_star_SUBJ = zeros(nbasis^2, 1);
    for l=1:ncohort    
        Ai_cov = kron(eval_basis(to{l}, bsbasis),eval_basis(to{l}, bsbasis));
        vii_SUBJ = (1/(ncohort*PN(l)*(PN(l)-1))) .*ones(1, PN(l)^2);
        vii_SUBJ([1: 1+PN(l): PN(l)^2]) =0;
        Vi_SUBJ = diag(vii_SUBJ);
        Gn_SUBJ =  Gn_SUBJ + Ai_cov' * Vi_SUBJ * Ai_cov;
        Sigma_star_SUBJ = Sigma_star_SUBJ + Ai_cov' * Vi_SUBJ * Sigma_SUBJ{l};
    end
    theta_SUBJ = inv(Gn_SUBJ + P_sigma) * Sigma_star_SUBJ;

    ss_bsv = (kron(ss_bp', ss_bp'))';
    rkhs_cov_SUBJ = reshape(ss_bsv * theta_SUBJ, length(rangeval1), length(rangeval1)); 

    for j = 1:1:length(para)
        Blc{i,j} = cov_func;
        Miblc(i,j)                    = sum(sum((Blc{i,j} - truecov).^2))/10000;
        Mablc(i,j)                    = max(max(abs(Blc{i,j} - truecov)));
        
        bw=[para(j),para(j)];
        [invalid,cov1]=mullwlsk(bw,'epan',tin,yin',win1,rangeval1,rangeval1);
        obs{i,j} = cov1;
        
        [invalid,cov2]=mullwlsk(bw,'epan',tin,yin',win2,rangeval1,rangeval1);
        subj{i,j} = cov2;
        
        Miobs(i,j)                    = sum(sum((obs{i,j} - truecov').^2))/10000;
        Maobs(i,j)                    = max(max(abs(obs{i,j} - truecov')));
        
        Misubj(i,j)                    = sum(sum((subj{i,j} - truecov').^2))/10000;
        Masubj(i,j)                    = max(max(abs(subj{i,j} - truecov')));
        
        ss{i,j} = rkhs_cov_SUBJ;
        Miss(i,j)                      = sum(sum((ss{i,j} - truecov').^2))/10000;
        Mass(i,j)                      = max(max(abs(ss{i,j} - truecov')));
    end
    disp(['The iteration number:',num2str(i)])
end
        
Ans_cov_MISE= [mean(Miblc); std(Miblc); mean(Miobs); std(Miobs); mean(Misubj); std(Misubj); mean(Miss); std(Miss)];
Ans_cov_MSAE= [mean(Mablc); std(Mablc); mean(Maobs); std(Maobs); mean(Masubj); std(Masubj); mean(Mass); std(Mass)];


figure
cov_plblc = zeros(size(truecov));
cov_plobs = zeros(size(truecov));
cov_plsubj = zeros(size(truecov));
cov_plrkhs = zeros(size(truecov));
% 
for i =1:1:iter_num
    cov_plblc= cov_plblc+ Blc{i,1}';
    cov_plobs= cov_plobs+ obs{i,3};
    cov_plsubj= cov_plsubj+ subj{i,3};
    cov_plrkhs = cov_plrkhs + ss{i,1};
end
cov_plblc = cov_plblc./iter_num;
cov_plobs = cov_plobs./iter_num;
cov_plsubj = cov_plsubj./iter_num;
cov_plrkhs = cov_plrkhs./iter_num;
figure
rangeval1 = 0:0.01:1;
lint=1;
for i=1:length(rangeval1)
    for j=1:length(rangeval1)
        truecov(i,j)=xeig4(rangeval1(i),lint)'*diag([1/4,1/9,1/16,1/25])*xeig4(rangeval1(j),lint);
    end
end
subplot(5,4,1)
mesh(rangeval1, rangeval1, truecov)
axis([0,1,0,1])
title('\textbf{Setting 1,~ $$\sigma=0.1$$}','Interpreter','latex','FontSize',12)
subplot(5,4,2)
mesh(rangeval1, rangeval1, truecov)
axis([0,1,0,1])
title('\textbf{Setting 1,~ $$\sigma=0.5$$}','Interpreter','latex','FontSize',12)
subplot(5,4,3)
mesh(rangeval1, rangeval1, truecov)
axis([0,1,0,1])
title('\textbf{Setting 2,~ $$\sigma=0.1$$}','Interpreter','latex','FontSize',12)
subplot(5,4,4)
mesh(rangeval1, rangeval1, truecov)
axis([0,1,0,1])
title('\textbf{Setting 2,~ $$\sigma=0.5$$}','Interpreter','latex','FontSize',12)

subplot(5,4,5)
mesh(rangeval1, rangeval1, cov_plblc101)
axis([0,1,0,1])
subplot(5,4,6)
mesh(rangeval1, rangeval1, cov_plblc105)
axis([0,1,0,1])
subplot(5,4,7)
mesh(rangeval1, rangeval1, cov_plblc201)
axis([0,1,0,1])
subplot(5,4,8)
mesh(rangeval1, rangeval1, cov_plblc205)
axis([0,1,0,1])


subplot(5,4,9)
mesh(rangeval1, rangeval1, cov_plobs101)
axis([0,1,0,1])
subplot(5,4,10)
mesh(rangeval1, rangeval1, cov_plobs105)
axis([0,1,0,1])
subplot(5,4,11)
mesh(rangeval1, rangeval1, cov_plobs201)
axis([0,1,0,1])
subplot(5,4,12)
mesh(rangeval1, rangeval1, cov_plobs205)
axis([0,1,0,1])

subplot(5,4,13)
mesh(rangeval1, rangeval1, cov_plsubj101)
axis([0,1,0,1])
subplot(5,4,14)
mesh(rangeval1, rangeval1, cov_plsubj105)
axis([0,1,0,1])
subplot(5,4,15)
mesh(rangeval1, rangeval1, cov_plsubj201)
axis([0,1,0,1])
subplot(5,4,16)
mesh(rangeval1, rangeval1, cov_plsubj205)
axis([0,1,0,1])

subplot(5,4,17)
mesh(rangeval1, rangeval1, cov_plrkhs101)
axis([0,1,0,1])
subplot(5,4,18)
mesh(rangeval1, rangeval1, cov_plrkhs105)
axis([0,1,0,1])
subplot(5,4,19)
mesh(rangeval1, rangeval1, cov_plrkhs201)
axis([0,1,0,1])
subplot(5,4,20)
mesh(rangeval1, rangeval1, cov_plrkhs205)
axis([0,1,0,1])


% figure
% mesh(truecov)