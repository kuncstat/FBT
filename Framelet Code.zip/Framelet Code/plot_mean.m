figure
rangeval1 = 0:0.01:1;
iter_num=500;
w1=1;
w2=.5;
mu_real =w1 * sin(3*pi*(rangeval1+0.5))+ w2 * rangeval1.^3;

plblc = zeros(size(mu_real));
plobs = zeros(size(mu_real));
plsubj = zeros(size(mu_real));

for i =1:1:iter_num
    plblc= plblc+ Blc{i,10}';
    plobs= plobs+ obs{i,11};
    plsubj= plsubj+ subj{i,12};
end
plblc = plblc./iter_num;
plobs = plobs./iter_num;
plsubj = plsubj./iter_num;
hold on
m1=plot(rangeval1, mu_real,'-r','LineWidth',2);

m2=plot(rangeval1,plblc,'--b','LineWidth',2);
%hold on
m3=plot(rangeval1,plobs,'-.g','LineWidth',2);
%hold on
m4=plot(rangeval1,plsubj,':m','LineWidth',2);
hold off
axis([0,1,-1.1,1.6]);
legend({'$$\mu$$','$$\hat{\mu}$$','$$\hat{\mu}_{obs}$$','$$\hat{\mu}_{subj}$$'},'Interpreter','latex','FontSize',12)
xlabel('Time');
ylabel('Values');