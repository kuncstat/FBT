function estimator_h = estimateHigh(coeffi,basis, scale_level,level_num)
estimator_hi = cell(level_num,1);
for m= 0:1:(level_num-1)
    m1 = length(coeffi{m+1,1});
    estimator_hi{m+1} = zeros(300,1);
    for k = 1:1:m1
        estimator_hi{m+1} = estimator_hi{m+1} + coeffi{m+1,1}(k)*basis{m+1,1}(k,:)';
    end
    estimator_hi{m+1} = estimator_hi{m+1}*(2.^((m+scale_level)/2));
end 
estimator_h = zeros(300,1);
for i= 1:1:level_num
    estimator_h = estimator_h + estimator_hi{i};
end


