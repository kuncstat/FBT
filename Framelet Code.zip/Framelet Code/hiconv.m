function hipath = hiconv(rangeval,m,n,basis)

m1 = -2.^m-n+1; 
m2 = 2.^(m+1);
lens =length(rangeval);
%m1 = -n+1; m2=2.^(m)-1;
tm = zeros(m2-m1+1,lens);
tau = n/(length(basis)-1);
basis = [basis,0];

hipath = zeros(size(tm));

for k = m1:1:m2
    tcopy = 2.^m * rangeval -k;
    tcopy(tcopy>n)=0;
    tcopy(tcopy<0)=0;

    tm(k-m1+1,:) = floor(tcopy/tau);
end
hipath = basis(tm+1);

