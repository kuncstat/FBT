function hipath1 = hipath(rangeval, scale_level, level_num, supp, basis)

% psai1 = [basis,0];

hipath1 = cell(level_num,1);

for m = 0:1:level_num-1
    hipath1{m+1} = hiconv(rangeval,m+scale_level,supp,basis);
end