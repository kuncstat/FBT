%Part I: the wavelet framelets
% show the b_0 and b_k(k=1,2,3),that is the coeffients of \tao_k (k=0,1,2,3)
t0 = 317784/7775 + 56*sqrt(16323699891)/2418025;
t1 = sqrt(11113747578360- 245493856965*t0)/62697600;
t2 = sqrt(1543080- 32655*t0)/40320;
t3 = sqrt(32655)/20160;
t01 = 7775*t0/4396 - 53854/1099;
t02 = t0/8 + 21;
b1 = [1, 4, -25, 40, -25, 4, 1] * t1;
b2 = [1, 4, t01-26, 52-4*t01, 6*t01-62, 52-4*t01, t01-26, 4, 1] * t2;
b3 = [1, 4, t02-26, t0-4*t02+44, 7*t02-4*t0-31, 6*t0+16-8*t02, 7*t02-4*t0-31, t0-4*t02+44, t02-26, 4, 1]*t3;

% the code is for scale function \phi(t) defined on [0,4]
bs0 = splinefunc(0);
phi = generate_phi(bs0);

% give the formula of C_{theta}phi ,which is defined on [-3,7]
Cphi = generate_Ctheta_phi(phi);

% the code is for wavelet functions {\psai(t)} 
% defined on [0,5] [0,6] and [0,7], respectively.
psai1 = psaifunc(b1,bs0);
psai2 = psaifunc(b2,bs0);
psai3 = psaifunc(b3,bs0);


%% The basic setting 
ncohort = 200;                  % the number of samples
rangeval = -0.99:0.01:2;        % the domain of mean function                                        
rangeval1 = 0:0.01:1;                                               


% Setting the resolution levels
level_num   = log2(ncohort);    
level_num   = floor(level_num); % maximal level

%% the smoothing parameter and threshold in different settings of mean functions
sigma =0.1;

% % Setting 1 
% Thr =floor(log10(ncohort)^2);  w1=1;w2=.5; scale_level = 3; para = [.38:0.1:1.08]; 
% mu_real = w1 * sin(3*pi*(rangeval+0.5))+ w2 * rangeval.^3;

% Setting 2
% Thr =floor(log10(ncohort)^2); w1=0.5;w2=.5; scale_level =6; para = [.1:0.04:.46];
% mu_real = w1 * (exp(-500*(rangeval-0.23).^2) + 2*exp(-2000*(rangeval-0.33).^2) + 4*exp(-8000*(rangeval-0.47).^2) + 3*exp(-16000*(rangeval-0.69).^2)  + exp(-32000*(rangeval-0.83).^2));

% Setting 3
% Thr =floor(log10(ncohort)^2);  w1=1;w2=.5; para = [.62:0.04:1.42]; scale_level = 3;
% mu_real = w1 * ((0.32+0.6*rangeval+0.3*exp(-100*(rangeval-0.3).^2)).*(rangeval>=0 & rangeval<=0.8) + (-0.28+0.6*rangeval+0.3*exp(-100*(rangeval-1.3).^2)).*(rangeval>0.8 & rangeval<=1));

mu_real =mu_real([100:200]);    % the true mean function
mu_real = mu_real';

% Smoothing Splines
norder = 4;  % the order of splines
ss_lambda = 0.01;  % the best regularization parameter via 5-fold cv
pord = 2; % the degree of penalized matrix P


%%  Iterations
iter_num =500; 

% Define the initial values of MISE and MSAE
Miblc = zeros(iter_num,length(para)); Mablc= zeros(iter_num,length(para));
Miobs = zeros(iter_num,length(para)); Maobs= zeros(iter_num,length(para));
Misubj = zeros(iter_num,length(para)); Masubj= zeros(iter_num,length(para));
Miss = zeros(iter_num,length(para)); Mass= zeros(iter_num,length(para));

Blc = cell(iter_num,length(para));
obs = cell(iter_num,length(para));
subj = cell(iter_num,length(para));
ss = cell(iter_num,length(para));
for i=1:1:iter_num
   [t,y,win2,to,yo] = generate_data(1, ncohort,w1,w2, sigma);
   Wii_SUBJ = []; PN=[];
   for k=1:ncohort
       PN = [PN, length(to{k})];
       weii = (1/(ncohort*PN(k))) .*ones(1, PN(k));
       Wii_SUBJ = [Wii_SUBJ, weii];
   end
   
   t = cell2mat(t); to = cell2mat(to);
   y = cell2mat(y); yo = cell2mat(yo); win2 = cell2mat(win2);
   win = ones(1,length(to))/ length(to);
   cVal = (2+3.5*sqrt(42))^2*0.49^2*mean(yo.^2)/0.08 * ones(size(para));
   PVal = sqrt(ncohort)* 0.8;
   fbt = estimation_framelets(t, y, scale_level, level_num, ncohort,Cphi, phi, psai1, psai2, psai3,rangeval, Thr, PVal, cVal);
   
   nbasis = floor((ncohort^2 /sum(1./PN))^(1/(2*2+1)))+50;
   BSB = create_bspline_basis([0,1], nbasis, norder);
   BSB = fdPar(BSB); bsbasis = getfd(BSB); bsbasis = getbasis(bsbasis);
   bsb_pv = eval_basis(to, bsbasis);
   ss_D = diff(eye(nbasis), pord);
   ss_bp = eval_basis(rangeval1, bsbasis);

   
   Wii_SUBJ = diag(Wii_SUBJ);
   Hn_SUBJ = bsb_pv' * Wii_SUBJ * bsb_pv + ss_lambda * ss_D' * ss_D;
   ss_coeffi_hat_SUBJ = inv(Hn_SUBJ) * bsb_pv' * Wii_SUBJ * yo';
   ss_hat_SUBJ =  ss_bp * ss_coeffi_hat_SUBJ;

    for j=1:1:length(para)
        Blc{i,j} = fbt;
        Miblc(i,j)                    = sum((Blc{i,j} - mu_real).^2)/100;
        Mablc(i,j)                    = max(abs(Blc{i,j} - mu_real));
        
        [invalid, mu1]=lwls(0.2661*para(j),'epan', 4, 3, 0, to, yo', win, rangeval1,0) ;
        obs{i,j} = mu1;
        
        [invalid, mu2]=lwls(0.2661*para(j),'epan', 4, 3, 0, to, yo', win2, rangeval1,0) ;
        subj{i,j} = mu2;
        
        ss{i,j} = ss_hat_SUBJ';
        
        Miobs(i,j)                    = sum((obs{i,j} - mu_real').^2)/100;
        Maobs(i,j)                    = max(abs(obs{i,j} - mu_real'));
        
        Misubj(i,j)                    = sum((subj{i,j} - mu_real').^2)/100;
        Masubj(i,j)                    = max(abs(subj{i,j} - mu_real'));
        
        Miss(i,j)                      = sum((ss{i,j} - mu_real').^2)/100;
        Mass(i,j)                      = max(abs(ss{i,j} - mu_real'));

          
    end
    
    if mod(i,10)==0
        disp(['The iteration number:', num2str(i)])
    end
end

%% Calculating the minimal MISE and MSAE with corresponding standard errors

%  Ans_MISE = [mean(Miblc); std(Miblc); mean(Miobs); std(Miobs); mean(Misubj); std(Misubj); mean(Miss); std(Miss)]; 
%  Ans_MSAE = [mean(Mablc); std(Mablc); mean(Maobs); std(Maobs); mean(Masubj); std(Masubj); mean(Mass); std(Mass)];



% figure
% plblc = zeros(size(mu_real'));
% plobs = zeros(size(mu_real'));
% plsubj = zeros(size(mu_real'));
% plss = zeros(size(mu_real'));
% % 
% for i =1:1:iter_num
%     plblc= plblc+ Blc{i,1}';
%     plobs= plobs+ obs{i,6};
%     plsubj= plsubj+ subj{i,6};
%     plss = plss + ss{i,1};
% end
% plblc = plblc./iter_num;
% plobs = plobs./iter_num;
% plsubj = plsubj./iter_num;
% plss = plss./iter_num;
% % 
% m1=plot(rangeval1, mu_real,'-r','LineWidth',2);
% hold on
% m2=plot(rangeval1,plblc,'--b','LineWidth',2);
% hold on
% m3=plot(rangeval1,plobs,'-.g','LineWidth',2);
% hold on
% m4=plot(rangeval1,plsubj,':m','LineWidth',2);
% hold on
% m5=plot(rangeval1,plss,'--y','LineWidth',2);
% hold off
% axis([0,1,-1.1,2.6]);
% legend({'$$\mu$$','$$FBT_{subj}$$','$$LLS_{obs}$$','$$LLS_{subj}$$', '$$SS_{subj}$$'},'Interpreter','latex','FontSize',12)
% xlabel('Time');
% ylabel('The Values of esrimators');
% 
% rangeval1 = 0:0.01:1;
% rangeval = 0:0.01:1;
% % w1=1;w2=0.5;
% % mu_real = w1 * sin(3*pi*(rangeval+0.5))+ w2 * rangeval.^3;
% 
% % w1=0.5;
% % mu_real = w1 * (exp(-500*(rangeval-0.23).^2) + 2*exp(-2000*(rangeval-0.33).^2) + 4*exp(-8000*(rangeval-0.47).^2) + 3*exp(-16000*(rangeval-0.69).^2)  + exp(-32000*(rangeval-0.83).^2));
% 
% w1=1;
% mu_real =w1 * ((0.32+0.6*rangeval+0.3*exp(-100*(rangeval-0.3).^2)).*...
%     (rangeval>=0 & rangeval<=0.8) + (-0.28+0.6*rangeval+0.3*...
%     exp(-100*(rangeval-1.3).^2)).*(rangeval>0.8 & rangeval<=1));
% figure
% subplot(1,4,1)
% rangeval1 = 0:0.01:1;
% s1=plot(rangeval1, mu_real,'-r','LineWidth',2);
% hold on
% s2=plot(rangeval1,plblc101,'--b','LineWidth',2);
% hold on
% s3=plot(rangeval1,plobs101,'--g','LineWidth',2);
% hold on
% s4=plot(rangeval1,plsubj101,'--m','LineWidth',2);
% hold on
% s5=plot(rangeval1,plss101,'--c','LineWidth',2);
% hold off
% axis([0,1,min(mu_real)-0.1,max(mu_real)+0.1]);
% % legend({'$$\mu_1$$','$$FBT_{subj}$$','$$LLS_{obs}$$','$$LLS_{subj}$$', '$$SS_{subj}$$'},'Interpreter','latex','FontSize',12)
% xlabel('Time');
% ylabel('Values');
% title('\textbf{Setting 1,~ $$\sigma=0.1$$}','Interpreter','latex','FontSize',12)
% 
% subplot(1,4,2)
% rangeval1 = 0:0.01:1;
% s1=plot(rangeval1, mu_real,'-r','LineWidth',2);
% hold on
% s2=plot(rangeval1,plblc105,'--b','LineWidth',2);
% hold on
% s3=plot(rangeval1,plobs105,'--g','LineWidth',2);
% hold on
% s4=plot(rangeval1,plsubj105,'--m','LineWidth',2);
% hold on
% s5=plot(rangeval1,plss105,'--c','LineWidth',2);
% hold off
% axis([0,1,min(mu_real)-0.1,max(mu_real)+0.1]);
% % legend({'$$\mu_1$$','$$FBT_{subj}$$','$$LLS_{obs}$$','$$LLS_{subj}$$', '$$SS_{subj}$$'},'Interpreter','latex','FontSize',12)
% xlabel('Time');
% ylabel('Values');
% title('\textbf{Setting 1,~ $$\sigma=0.5$$}','Interpreter','latex','FontSize',12)
% 
% subplot(1,4,3)
% rangeval1 = 0:0.01:1;
% s1=plot(rangeval1, mu_real,'-r','LineWidth',2);
% hold on
% s2=plot(rangeval1,plblc201,'--b','LineWidth',2);
% hold on
% s3=plot(rangeval1,plobs201,'--g','LineWidth',2);
% hold on
% s4=plot(rangeval1,plsubj201,'--m','LineWidth',2);
% hold on
% s5=plot(rangeval1,plss201,'--c','LineWidth',2);
% hold off
% axis([0,1,min(mu_real)-0.1,max(mu_real)+0.1]);
% % legend({'$$\mu_1$$','$$FBT_{subj}$$','$$LLS_{obs}$$','$$LLS_{subj}$$', '$$SS_{subj}$$'},'Interpreter','latex','FontSize',12)
% xlabel('Time');
% ylabel('Values');
% title('\textbf{Setting 2,~ $$\sigma=0.1$$}','Interpreter','latex','FontSize',12)
% 
% subplot(1,4,4)
% rangeval1 = 0:0.01:1;
% s1=plot(rangeval1, mu_real,'-r','LineWidth',2);
% hold on
% s2=plot(rangeval1,plblc205,'--b','LineWidth',2);
% hold on
% s3=plot(rangeval1,plobs205,'--g','LineWidth',2);
% hold on
% s4=plot(rangeval1,plsubj205,'--m','LineWidth',2);
% hold on
% s5=plot(rangeval1,plss205,'--c','LineWidth',2);
% hold off
% axis([0,1,min(mu_real)-0.1,max(mu_real)+0.1]);
% legend({'$$\mu_3$$','$$FBT_{subj}$$','$$LLS_{obs}$$','$$LLS_{subj}$$', '$$SS_{subj}$$'},'Interpreter','latex','FontSize',12)
% xlabel('Time');
% ylabel('Values');
% title('\textbf{Setting 2,~ $$\sigma=0.5$$}','Interpreter','latex','FontSize',12)
% 
% 
% 
% 
