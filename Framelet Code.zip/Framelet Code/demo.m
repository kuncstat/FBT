%% estimation by wavelet thresholding %%
% The real data
% Case1: the cd number data
load('/Users/chengkun/Desktop/Framelet Code/cd4_num.mat')
load('/Users/chengkun/Desktop/Framelet Code/time.mat')
ncohort = length(time);                  % the number of samples
t = cell(size(time));to = cell(size(time));
y = cell(size(cd4_num));yo = cell(size(cd4_num));
win2 = cell(size(y));
PN = [];
for i=1:1:ncohort
    num = length(time{i});
    PN = [PN, num];
    t_symR{i} = 2-time{i}/6;
    t_symL{i} = -time{i}/6;
    t{i} = [t_symL{i}', time{i}'/6, t_symR{i}'];
    y{i} = [cd4_num{i}', cd4_num{i}', cd4_num{i}']./30;
    Mi = length(time{i});
    win2{i} = ones(1,Mi)/Mi;
    win2{i} = win2{i}/ncohort;

    Ni = length(y{i});
    y{i} = y{i}/Ni;
    to{i} = time{i}'./6;
    yo{i} = cd4_num{i}'/30;
end
tocell = to(PN~=1); tcov = t(PN~=1); t = cell2mat(t); to = cell2mat(to);  
yocell = yo(PN~=1); ycov = y(PN~=1); y = cell2mat(y); yo = cell2mat(yo); 
taub = 0.1;
y(y>taub) = taub;
win2 = cell2mat(win2);win = ones(1,length(to))/ length(to);

%%
%Part II: the wavelet framelets
% show the b_0 and b_k(k=1,2,3),that is the coeffients of \tao_k (k=0,1,2,3)
t0 = 317784/7775 + 56*sqrt(16323699891)/2418025;
t1 = sqrt(11113747578360- 245493856965*t0)/62697600;
t2 = sqrt(1543080- 32655*t0)/40320;
t3 = sqrt(32655)/20160;
t01 = 7775*t0/4396 - 53854/1099;
t02 = t0/8 + 21;
b1 = [1, 4, -25, 40, -25, 4, 1] * t1;
b2 = [1, 4, t01-26, 52-4*t01, 6*t01-62, 52-4*t01, t01-26, 4, 1] * t2;
b3 = [1, 4, t02-26, t0-4*t02+44, 7*t02-4*t0-31, 6*t0+16-8*t02, 7*t02-4*t0-31, t0-4*t02+44, t02-26, 4, 1]*t3;

% the code is for scale function \phi(t) defined on [0,4]
bs0 = splinefunc(0);
phi = generate_phi(bs0);

% give the formula of C_{theta}phi ,which is defined on [-3,7]
Cphi = generate_Ctheta_phi(phi);

% the code is for wavelet functions {\psai(t)} 
% defined on [0,5] [0,6] and [0,7], respectively.
psai1 = psaifunc(b1,bs0);
psai2 = psaifunc(b2,bs0);
psai3 = psaifunc(b3,bs0);

%% Part III: Get the coefficients

% First, obtain \alpha
PVal=sqrt(ncohort)*0.8;
Thr =64; cVal=(2+6*sqrt(7))^2*0.86^2*mean(yo.^2))/0.08;
level_num = floor(log2(ncohort)/2);scale_level=0;
rangeval = [-0.99:0.01:2];

mu_hat1 =  estimation_framelets(t, y, scale_level, level_num,...
 ncohort,Cphi, phi, psai1, psai2, psai3,rangeval,Thr, PVal, cVal);

rangeval1 = [0:0.01:1]; 
[invalid, mu1]=lwls(0.242,'epan', 4,3, 0, to, yo', win, rangeval1,0) ;
[invalid, mu2]=lwls(0.261,'epan', 4,3, 0, to, yo', win2, rangeval1,0) ;
% the estimation of mean function via penalized splines
norder = 4;  % the order of splines
nbasis = floor((ncohort^2 /sum(1./PN))^(1/(2*2+1)));
BSB = create_bspline_basis([0,1], nbasis, norder);
BSB = fdPar(BSB); bsbasis = getfd(BSB); bsbasis = getbasis(bsbasis);
bsb_pv = eval_basis(to, bsbasis);

Wii = [];
for i=1:ncohort    
    weii = (1/(ncohort*PN(i))) .*ones(1, PN(i));
    Wii = [Wii, weii];
end
Wii = diag(Wii);

ss_lambda = .21;  % the regularization parameter
pord = 2; % the degree of penalized matrix P
ss_D = diff(eye(nbasis), pord);
Hn = bsb_pv' * Wii * bsb_pv + ss_lambda * ss_D' * ss_D;
ss_coeffi_hat = inv(Hn) * bsb_pv' * Wii * yo';
ss_bp = eval_basis(rangeval1, bsbasis);
ss_hat =  ss_bp * ss_coeffi_hat; 


figure
m1=plot(rangeval1*6, mu_hat1'*30,'-r','LineWidth',4); 
hold on; m4=plot(rangeval1*6, ss_hat*30,'-y','LineWidth',4);
hold on; m2=plot(rangeval1*6, mu1*30,'-g','LineWidth',4); 
hold on; m3=plot(rangeval1*6, mu2*30,'-b','LineWidth',4);
hold off
axis([0, 6, 0, 70]);
legend({'FBT_{subj}','SS_{subj}','LLS_{obs}',...
 'LLS_{subj}'},'FontSize',12)
xlabel('Time(year)');
ylabel('CD4 Percentage');

figure
m11=plot(rangeval1*6, mu_hat1'*30,'-r','LineWidth',4.5); 
hold on; m22 = scatter(to*6,yo*30, 'k');
hold off
axis([0, 6, 0, 70]);
xlabel('Time(year)');
ylabel('CD4 Percentage');
%% The estimation of covariance function
% centre the observations with the mean estimator
% the raw covariance
ncohort = 256;
inival = 0;
to = cell2mat(tocell); yo = cell2mat(yocell);
pni =find(PN~=1); PN = PN(pni);
raw_covariance =zeros(3*length(to),3*length(to));
thrr =0.05;
for i=1:1:ncohort  
    muP = mu_hat1(floor(tocell{i}/0.01)+1);
    y11{i} = yocell{i}-muP';

    Ni = length(y11{i});
    
    out1 = repmat(y11{i}, Ni, 1);
    out1 = (out1 - diag(diag(out1)))/(3*Ni);
    out1(out1>thrr) =thrr;
    out1(out1<-thrr) =thrr;
    
    out2 = y11{i}'/(3*Ni-3);
    out2 = repmat(out2, 1, Ni); 
    out2(out2>thrr) =thrr;
    out2(out2<-thrr) =-thrr;

    
    out = out1.* out2;
    out = [out,out,out;out,out,out;out,out,out];
    
%     wi = 9*Ni*(Ni-1);
%     out = out/wi;
   
    inival1 = inival+1;
    inival  = inival + 3*Ni;
    raw_covariance(inival1:inival, inival1:inival) = out;
end
Cov_raw = raw_covariance; % the raw covariance
Thr=18;
cVal =(2+3.5*sqrt(49))^2*0.49^4*std(yo).^4/0.08;
% reconstruct the covariance function via the 2D framelet block
% thresholding method
% Note: the number of each subject should be larger than 1, otherwise, the
% raw covariance of that subject will be NAN floor(log2(ncohort)/2) 
tcov = cell2mat(tcov);
[cov_func]  = cov_reconstruct(tcov,Cov_raw, 2:-0.01:-0.99, 1, 1, ncohort,...
    'Cphi',Cphi, 'phi',phi, 'psai1',psai1, 'psai2',psai2, 'psai3',psai3, Thr, cVal);
% rconstruct the covariance function via the LLSs
regular =0;

[res1] = getRawCov(yocell,tocell,rangeval1, mu1, regular, 1, 'obs');
[res2] = getRawCov(yocell,tocell,rangeval1, mu2, regular, 1, 'subj');
tin = res1.tpairn; yin = res1.cxxn;
win1 = res1.win;   win2 = res2.win;

para1 = 0.649; bw1=[para1, para1];
para2 = 0.763; bw2 = [para2, para2];
[invalid,cov1]=mullwlsk(bw1,'epan',tin,yin',win1,rangeval1,rangeval1);
[invalid,cov2]=mullwlsk(bw2,'epan',tin,yin',win2,rangeval1,rangeval1);

% RKHS: obtain the raw covariance
Sigma_SUBJ = cell(1, ncohort);
Bb_cov = zeros(nbasis, nbasis); % the values at T_ijl
for i=1:ncohort
    sigmai_SUBJ = ss_hat(floor(tocell{i}/0.01)+1);
    rci_SUBJ = (yocell{i}-sigmai_SUBJ')' * (yocell{i}-sigmai_SUBJ'); 
    rci_SUBJ = rci_SUBJ - diag(diag(rci_SUBJ));
    Sigma_SUBJ{i} = rci_SUBJ(:);
        
    bsb_pv_cov = eval_basis(tocell{i}, bsbasis);
    Bb_cov = Bb_cov + bsb_pv_cov' * bsb_pv_cov;
end
Gbn_cov = Bb_cov/length(to);
lambda_sigma = .18;  % the smoohthing parameters
Pb_cov = ss_D' * ss_D; % the penality \bar{P}
P_sigma = lambda_sigma * (kron(Gbn_cov, Pb_cov) + kron(Pb_cov, Gbn_cov))+...
    lambda_sigma^2 * (kron(Pb_cov, Pb_cov)); % the penality matrix 
Gn_SUBJ = zeros(nbasis^2, nbasis^2); Sigma_star_SUBJ = zeros(nbasis^2, 1);
for i=1:ncohort    
    Ai_cov = kron(eval_basis(tocell{i}, bsbasis),eval_basis(tocell{i}, bsbasis));

    % SUBJ weighing 
    vii_SUBJ = (1/(ncohort*PN(i)*(PN(i)-1))) .*ones(1, PN(i)^2);
    vii_SUBJ([1: 1+PN(i): PN(i)^2]) =0;
    Vi_SUBJ = diag(vii_SUBJ);
    Gn_SUBJ =  Gn_SUBJ + Ai_cov' * Vi_SUBJ * Ai_cov;
    Sigma_star_SUBJ = Sigma_star_SUBJ + Ai_cov' * Vi_SUBJ * Sigma_SUBJ{i};  
end
theta_SUBJ = inv(Gn_SUBJ + P_sigma) * Sigma_star_SUBJ;
ss_bsv = (kron(ss_bp', ss_bp'))';
ss_cov_SUBJ = reshape(ss_bsv * theta_SUBJ, length(rangeval1), length(rangeval1)); 

% plot the estimators
figure
subplot(2,2,1)
mesh(rangeval1*6, rangeval1*6,(cov_func+cov_func')/2*900);
axis([0,6,0,6]);
xlabel('Time(year)');ylabel('Time(year)');
title('FBT_{subj}','FontSize',12)
subplot(2,2,2)
mesh(rangeval1*6, rangeval1*6,(ss_cov_SUBJ+ss_cov_SUBJ')/2 *900)
axis([0,6,0,6]);
xlabel('Time(year)');ylabel('Time(year)');
title('RKHS_{subj}','FontSize',12)
subplot(2,2,3)
mesh(rangeval1*6, rangeval1*6,(cov1+cov1')/2*900)
axis([0,6,0,6]);
xlabel('Time(year)');ylabel('Time(year)');
title('LLS_{obs}','FontSize',12)
subplot(2,2,4)
mesh(rangeval1*6, rangeval1*6,(cov2+cov2')/2*900)
axis([0,6,0,6]);
xlabel('Time(year)');ylabel('Time(year)');
title('LLS_{subj}','FontSize',12)
