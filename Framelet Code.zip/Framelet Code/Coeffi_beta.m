function [beta1, beta11] = Coeffi_beta(t,y, ncohort,scale_level, level_num, basis, supp, Thr, PVal, cVal)

beta1 = cell(level_num,1); beta11 = cell(level_num,1);

for m = 0:1:level_num-1
    beta1{m+1} = getValue(t, y, ncohort,m+scale_level, supp, basis, PVal);
end

beta11 = BlockThresholding(t, beta1, ncohort,Thr, cVal);